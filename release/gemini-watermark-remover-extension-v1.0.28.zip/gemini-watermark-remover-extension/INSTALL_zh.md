# Gemini Watermark Remover Chrome extension v1.0.28

## Install

1. Extract this zip file.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the extracted `gemini-watermark-remover-extension` folder.

## Update

Download the new zip, replace the extracted folder, then click Reload on the extension card.

## Privacy

The extension runs on Gemini pages only and processes generated image previews, copy actions, and download actions in the browser. It does not collect accounts, prompts, chat content, or personal data. To complete local processing, it may request Gemini and Googleusercontent image assets.
